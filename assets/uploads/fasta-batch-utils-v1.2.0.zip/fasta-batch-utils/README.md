# FASTA 批量处理脚本

一个只依赖 Python 标准库的小工具，用来干这几件事：

- 统计一批 FASTA 文件的条数、长度分布、GC 含量
- 按长度区间或关键字筛选序列
- 批量重命名序列头（加前缀、补零编号、拼原文件名）
- 导出成表格，直接进 Excel 或 pandas

**为什么不直接用 Biopython？** 装环境本身经常就是最大的阻力。
日常这几件事这个脚本足够了；真需要做比对、翻译、系统发育分析时再上 Biopython。

## 环境要求

Python 3.9 或更高。没有第三方依赖，`pip install` 都不用跑。

检查一下：

```bash
python3 --version
```

## 用法

把 `fasta_batch_utils.py` 放到任意目录，在该目录下执行：

### 1. 统计

```bash
python3 fasta_batch_utils.py summary *.fasta
python3 fasta_batch_utils.py summary ./sequences/     # 也可以直接给目录
```

输出示例：

```
文件              条数    最短      平均    最长       总长   平均GC
------------------------------------------------------------------
batch1.fasta       128      42     318.6    1204     40784    51.3%
batch2.fasta        96     118    402.1     998     38602    48.9%
------------------------------------------------------------------
合计 2 个文件 · 224 条序列
```

### 2. 筛选

```bash
# 只保留 100–2000 bp 的序列
python3 fasta_batch_utils.py filter *.fasta --min-len 100 --max-len 2000 --out clean.fasta

# 序列头里带 "IgG" 的留下，带 "control" 的丢掉
python3 fasta_batch_utils.py filter *.fasta --include IgG --exclude control --out igg.fasta
```

### 3. 重命名

```bash
# 统一改成 SAMPLE1_001、SAMPLE1_002 …
python3 fasta_batch_utils.py rename *.fasta --prefix SAMPLE1_ --pad 3 --out renamed.fasta

# 想保留来源信息，就额外拼上原文件名
python3 fasta_batch_utils.py rename *.fasta --prefix S_ --pad 4 --keep-every --out renamed.fasta
```

### 4. 导出表格

```bash
python3 fasta_batch_utils.py tsv *.fasta --out records.tsv
```

导出的文件以 UTF-8 BOM 开头，Excel 双击打开不会乱码；用 pandas 读也很顺：

```python
import pandas as pd
df = pd.read_csv("records.tsv", sep="\t")
df[df.length > 300].sort_values("gc_percent")
```

## 已知边界

- 序列统一转成**大写**后统计 GC，小写软屏蔽区（soft-masked）不单独区分
- 不解析 FASTA 以外的格式（`.gb`、`.embl` 请先转换）
- 单文件是整体读进内存的。几万条序列没问题，上百万条建议按染色体拆文件处理
- 筛选依据是序列头里的文本，不做正则。需要正则的话在 `cmd_filter` 里改一行就行

## 反馈

用着有问题或者想要新功能，[写邮件](mailto:qgle@hotmail.com)告诉我。
