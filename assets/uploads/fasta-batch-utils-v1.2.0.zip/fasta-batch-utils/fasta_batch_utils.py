#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fasta_batch_utils.py — 批量处理 FASTA 文件的小工具（只用标准库）

四个子命令：

    summary  统计每个文件的序列条数、长度分布、GC 含量
    filter   按长度 / 关键字筛选，导出新的 FASTA
    rename   批量重命名序列头，可选加前缀、补零编号
    tsv      导出成表格，方便直接进 Excel / pandas

例子：

    python fasta_batch_utils.py summary  examples/*.fasta
    python fasta_batch_utils.py filter   in.fasta --min-len 100 --max-len 2000 --out clean.fasta
    python fasta_batch_utils.py filter   in.fasta --include " IgG " --out igg.fasta
    python fasta_batch_utils.py rename   in.fasta --prefix SAMPLE1 --pad 3 --out renamed.fasta
    python fasta_batch_utils.py tsv      in.fasta --out records.tsv

设计上刻意不依赖 Biopython：装环境本身经常就是最大的阻力。
需要更复杂的比对时再用 Biopython，日常这几件事这个脚本够了。
"""

from __future__ import annotations

import argparse
import csv
import glob
import os
import sys
from dataclasses import dataclass, field


# --------------------------------------------------------------------------- #
# 解析
# --------------------------------------------------------------------------- #

@dataclass
class Record:
    """一条序列。desc 是 header 去掉 id 之后的部分。"""

    id: str
    desc: str
    seq: str
    source: str = ""

    @property
    def length(self) -> int:
        return len(self.seq)

    @property
    def gc(self) -> float:
        """GC 含量，0~1。空序列返回 0。"""
        if not self.seq:
            return 0.0
        gc = self.seq.count("G") + self.seq.count("C")
        return gc / len(self.seq)

    @property
    def header(self) -> str:
        return f"{self.id} {self.desc}".strip()

    def wrap(self, width: int = 70) -> str:
        seq = self.seq
        lines = [seq[i : i + width] for i in range(0, len(seq), width)] or [""]
        return "\n".join(lines)


def read_fasta(path: str) -> list[Record]:
    """
    读取单个 FASTA 文件。

    容错处理：允许空行；允许序列跨多行；遇到下一个 '>' 才收尾。
    序列统一转大写，空白全部去掉。
    """
    records: list[Record] = []
    cur_id: str | None = None
    cur_desc = ""
    chunks: list[str] = []

    def flush() -> None:
        if cur_id is None:
            return
        seq = "".join(chunks).upper()
        records.append(Record(cur_id, cur_desc, seq, os.path.basename(path)))

    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            line = line.rstrip("\n").rstrip("\r")
            if not line.strip():
                continue
            if line.startswith(">"):
                flush()
                head = line[1:].strip()
                parts = head.split(None, 1)
                cur_id = parts[0] if parts else ""
                cur_desc = parts[1] if len(parts) > 1 else ""
                chunks = []
            else:
                chunks.append("".join(line.split()))
    flush()
    return records


def expand_inputs(patterns: list[str]) -> list[str]:
    """把命令行参数展开成文件列表，支持通配符与目录。"""
    files: list[str] = []
    for p in patterns:
        if os.path.isdir(p):
            for ext in ("*.fasta", "*.fa", "*.fna", "*.ffn", "*.fas"):
                files.extend(sorted(glob.glob(os.path.join(p, ext))))
        else:
            hits = sorted(glob.glob(p))
            files.extend(hits if hits else [p])
    # 去重但保持顺序
    seen: set[str] = set()
    out: list[str] = []
    for f in files:
        if f not in seen:
            seen.add(f)
            out.append(f)
    return out


# --------------------------------------------------------------------------- #
# 子命令
# --------------------------------------------------------------------------- #

def cmd_summary(args: argparse.Namespace) -> int:
    files = expand_inputs(args.inputs)
    if not files:
        print("没找到输入文件。", file=sys.stderr)
        return 1

    rows: list[tuple] = []
    total_records = 0

    for path in files:
        if not os.path.isfile(path):
            print(f"跳过（不存在）：{path}", file=sys.stderr)
            continue
        records = read_fasta(path)
        if not records:
            rows.append((os.path.basename(path), 0, 0, 0, 0.0, 0.0, 0.0))
            continue
        lengths = [r.length for r in records]
        gcs = [r.gc for r in records]
        rows.append(
            (
                os.path.basename(path),
                len(records),
                min(lengths),
                sum(lengths) / len(lengths),
                max(lengths),
                sum(lengths),
                sum(gcs) / len(gcs),
            )
        )
        total_records += len(records)

    name_w = max([len(r[0]) for r in rows] + [12])
    header = (
        f"{'文件'.ljust(name_w)}  {'条数':>6}  {'最短':>6}  {'平均':>8}  "
        f"{'最长':>6}  {'总长':>9}  {'平均GC':>7}"
    )
    print(header)
    print("-" * len(header))
    for name, n, lo, mean, hi, total, gc in rows:
        print(
            f"{name.ljust(name_w)}  {n:>6}  {lo:>6}  {mean:>8.1f}  "
            f"{hi:>6}  {total:>9}  {gc * 100:>6.1f}%"
        )
    print("-" * len(header))
    print(f"合计 {len(rows)} 个文件 · {total_records} 条序列")
    return 0


def cmd_filter(args: argparse.Namespace) -> int:
    files = expand_inputs(args.inputs)
    kept: list[Record] = []
    scanned = 0

    for path in files:
        if not os.path.isfile(path):
            print(f"跳过（不存在）：{path}", file=sys.stderr)
            continue
        for r in read_fasta(path):
            scanned += 1
            if r.length < args.min_len:
                continue
            if args.max_len and r.length > args.max_len:
                continue
            if args.include and args.include.lower() not in r.header.lower():
                continue
            if args.exclude and args.exclude.lower() in r.header.lower():
                continue
            kept.append(r)

    write_fasta(kept, args.out)
    print(f"扫描 {scanned} 条，保留 {kept.count and len(kept)} 条 → {args.out}")
    return 0


def cmd_rename(args: argparse.Namespace) -> int:
    files = expand_inputs(args.inputs)
    out_records: list[Record] = []
    counter = 0

    for path in files:
        if not os.path.isfile(path):
            print(f"跳过（不存在）：{path}", file=sys.stderr)
            continue
        for r in read_fasta(path):
            counter += 1
            num = str(counter).zfill(args.pad) if args.pad else str(counter)
            new_id = f"{args.prefix}{num}" if args.prefix else f"{r.id}"
            if args.keep_every:
                prefix_src = os.path.splitext(os.path.basename(path))[0]
                new_id = f"{prefix_src}_{new_id}"
            out_records.append(Record(new_id, r.desc, r.seq, r.source))

    write_fasta(out_records, args.out)
    print(f"重命名 {len(out_records)} 条 → {args.out}")
    return 0


def cmd_tsv(args: argparse.Namespace) -> int:
    files = expand_inputs(args.inputs)
    rows: list[dict] = []

    for path in files:
        if not os.path.isfile(path):
            print(f"跳过（不存在）：{path}", file=sys.stderr)
            continue
        for r in read_fasta(path):
            rows.append(
                {
                    "id": r.id,
                    "description": r.desc,
                    "length": r.length,
                    "gc_percent": round(r.gc * 100, 2),
                    "sequence": r.seq,
                    "source_file": r.source,
                }
            )

    if not rows:
        print("没有内容可导出。", file=sys.stderr)
        return 1

    with open(args.out, "w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(
            fh, fieldnames=list(rows[0].keys()), delimiter="\t", extrasaction="ignore"
        )
        writer.writeheader()
        writer.writerows(rows)

    print(f"导出 {len(rows)} 行 → {args.out}")
    print("（UTF-8 BOM 开头，Excel 直接双击打开不乱码）")
    return 0


def write_fasta(records: list[Record], path: str, width: int = 70) -> None:
    with open(path, "w", encoding="utf-8") as fh:
        for r in records:
            fh.write(f">{r.header}\n{r.wrap(width)}\n")


# --------------------------------------------------------------------------- #
# 入口
# --------------------------------------------------------------------------- #

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="fasta_batch_utils.py",
        description="批量处理 FASTA：统计 / 筛选 / 重命名 / 导出表格（无第三方依赖）",
    )
    sub = p.add_subparsers(dest="command", required=True)

    s = sub.add_parser("summary", help="统计条数与长度分布")
    s.add_argument("inputs", nargs="+", help="FASTA 文件、通配符或目录")
    s.set_defaults(func=cmd_summary)

    f = sub.add_parser("filter", help="按长度或关键字筛选")
    f.add_argument("inputs", nargs="+")
    f.add_argument("--min-len", type=int, default=0, help="最短长度，默认 0")
    f.add_argument("--max-len", type=int, default=0, help="最长长度，0 表示不限")
    f.add_argument("--include", default="", help="序列头必须包含的关键字")
    f.add_argument("--exclude", default="", help="序列头包含则丢弃")
    f.add_argument("--out", default="filtered.fasta")
    f.set_defaults(func=cmd_filter)

    r = sub.add_parser("rename", help="批量重命名序列头")
    r.add_argument("inputs", nargs="+")
    r.add_argument("--prefix", default="", help="新 ID 前缀，例如 SAMPLE1_")
    r.add_argument("--pad", type=int, default=0, help="编号补零位数，例如 3 → 001")
    r.add_argument("--keep-every", action="store_true", help="额外拼上原文件名，便于溯源")
    r.add_argument("--out", default="renamed.fasta")
    r.set_defaults(func=cmd_rename)

    t = sub.add_parser("tsv", help="导出成制表符表格")
    t.add_argument("inputs", nargs="+")
    t.add_argument("--out", default="records.tsv")
    t.set_defaults(func=cmd_tsv)

    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
